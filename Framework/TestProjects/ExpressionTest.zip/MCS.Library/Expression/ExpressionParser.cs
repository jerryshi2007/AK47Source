#region
// -------------------------------------------------
// Assembly	��	DeluxeWorks.Library
// FileName	��	ExpressionParser.cs
// Remark	��	�Ա���ʽ���н�������
// -------------------------------------------------
// VERSION  	AUTHOR		DATE			CONTENT
// 1.0		    ���ķ�	    20070430		����
// -------------------------------------------------
#endregion
using System;
using System.Text;
using System.Collections.Generic;

namespace MCS.Library.Expression
{
	/// <summary>
	/// ����ʽʶ����
	/// </summary>
	/// <remarks>
	/// �Ա���ʽ���н�������
	/// </remarks>
	public sealed class ExpressionParser
	{
		#region ���캯��
		private ExpressionParser()
		{
		}

		#endregion

		#region delegate Define
		private delegate ExpTreeNode DoNextOP(ParsingContext context);
		#endregion

		#region private define
		#region private variable define
		private static ExpressionParser instance = new ExpressionParser();
		#endregion

		#region ParsingContext
		private class ParsingContext
		{
			private int position = 0;
			private bool outputIdentifiers = false;
			private ParseIdentifier identifiers = null;

			private char[] expressionChars = null;

			private ParseIdentifier currentIdentifier = null;
			private ParseIdentifier parentIdentifier = null;

			public ParsingContext(string expression)
			{
				this.expressionChars = new Char[expression.Length + 1];

				expression.CopyTo(0, this.expressionChars, 0, expression.Length);
				this.expressionChars[expression.Length] = '\0';
			}

			public char CurrentChar
			{
				get { return this.expressionChars[this.position]; }
			}

			public ParseIdentifier CurrentIdentifier
			{
				get { return this.currentIdentifier; }
				set { this.currentIdentifier = value; }
			}

			public ParseIdentifier ParentIdentifier
			{
				get { return this.parentIdentifier; }
				set { this.parentIdentifier = value; }
			}

			public char[] ExpressionChars
			{
				get { return this.expressionChars; }
			}

			public int Position
			{
				get { return this.position; }
				set { this.position = value; }
			}

			public bool OutputIdentifiers
			{
				get { return this.outputIdentifiers; }
				set { this.outputIdentifiers = value; }
			}

			public ParseIdentifier Identifiers
			{
				get { return this.identifiers; }
				set { this.identifiers = value; }
			}
		}
		#endregion ParsingContext

		#region private function define

		/// <summary>
		/// ��ʼ����һ�α���ʽ
		/// </summary>
		/// <returns></returns>
		private ExpTreeNode DoExpression(ParsingContext context)
		{
			return DoLogicalOR(context);
		}

		private static ExpTreeNode DoLogical_AND_OR(ParsingContext context, char chSensitive, Operation_IDs oID, DoNextOP doNextOP)
		{
			ExpTreeNode node = null;
			ExpTreeNode node1 = doNextOP(context);
			ExpTreeNode node2 = null;

			while (context.CurrentChar == chSensitive)
			{
				int nPos = context.Position;
				char op = context.ExpressionChars[context.Position++];

				if (op == chSensitive)
				{
					OutputID(context, oID, chSensitive.ToString() + chSensitive.ToString(), nPos);
					context.Position++;
				}

				node2 = doNextOP(context);

				node = NewTreeNode(context, node1, node2, oID, nPos);

				node1 = node;
			}

			return node1;
		}

		private ExpTreeNode DoLogicalOR(ParsingContext context)
		{
			return DoLogical_AND_OR(context, '|', Operation_IDs.OI_LOGICAL_OR, new DoNextOP(DoLogicalAND));
		}

		/// <summary>
		/// �߼���
		/// </summary>
		/// <returns></returns>
		private ExpTreeNode DoLogicalAND(ParsingContext context)
		{
			return DoLogical_AND_OR(context, '&', Operation_IDs.OI_LOGICAL_AND, new DoNextOP(DoLogicalOP));
		}

		/// <summary>
		/// �߼��Ƚ�����
		/// </summary>
		/// <returns></returns>
		private ExpTreeNode DoLogicalOP(ParsingContext context)
		{
			ExpTreeNode node = null;
			ExpTreeNode node1 = DoAddSub(context);
			ExpTreeNode node2 = null;

			char op = context.CurrentChar;

			string strID = string.Empty;

			while (op == '>' || op == '<' || op == '=')
			{
				int nPos = context.Position;

				Operation_IDs oID = Operation_IDs.OI_NONE;

				if (context.ExpressionChars[++context.Position] == '=')
				{
					switch (op)
					{
						case '>':	//>=
							oID = Operation_IDs.OI_GREATEQUAL;
							strID = ">=";
							break;
						case '<':	//<=
							oID = Operation_IDs.OI_LESSEQUAL;
							strID = "<=";
							break;
						case '=':	//==
							oID = Operation_IDs.OI_EQUAL;
							strID = "==";
							break;
						default: throw ParsingException.NewParsingException(ParseError.peInvalidOperator,
										context.Position, op.ToString());
					}

					context.Position++;
				}
				else
				{
					if (context.CurrentChar == '>')
					{
						if (op == '<')	//<>
						{
							strID = "<>";
							oID = Operation_IDs.OI_NOT_EQUAL;
							context.Position++;
						}
						else
							throw ParsingException.NewParsingException(ParseError.peInvalidOperator,
									context.Position, op.ToString());
					}
					else
					{
						switch (op)
						{
							case '>':
								oID = Operation_IDs.OI_GREAT;
								strID = ">";
								break;
							case '<':
								oID = Operation_IDs.OI_LESS;
								strID = "<";
								break;
							default:
								throw ParsingException.NewParsingException(ParseError.peInvalidOperator,
									 context.Position, op.ToString());
						}
					}
				}

				OutputID(context, oID, strID, nPos);

				node2 = DoAddSub(context);

				node = NewTreeNode(context, node1, node2, oID, nPos);

				node1 = node;

				op = context.CurrentChar;
			}

			return node1;
		}

		/// <summary>
		/// �����Ӽ�����
		/// </summary>
		/// <returns></returns>
		private ExpTreeNode DoAddSub(ParsingContext context)
		{
			ExpTreeNode node = null;
			ExpTreeNode node1 = DoMulDiv(context);
			ExpTreeNode node2 = null;

			char ch = context.CurrentChar;
			while (ch == '-' || ch == '+')
			{
				Operation_IDs oID = Operation_IDs.OI_NONE;

				oID = (ch == '-') ? Operation_IDs.OI_MINUS : Operation_IDs.OI_ADD;

				OutputID(context, oID, ch.ToString(), context.Position);

				int nPos = context.Position;

				context.Position++;

				node2 = DoMulDiv(context);

				node = NewTreeNode(context, node1, node2, oID, nPos);

				node1 = node;

				ch = context.CurrentChar;
			}

			return node1;
		}

		/// <summary>
		/// �����˳�����
		/// </summary>
		/// <returns></returns>
		private ExpTreeNode DoMulDiv(ParsingContext context)
		{
			ExpTreeNode node = null;
			ExpTreeNode node1 = DoSgOP(context);
			ExpTreeNode node2 = null;

			char ch = context.CurrentChar;
			while (ch == '*' || ch == '/')
			{
				Operation_IDs oID = Operation_IDs.OI_NONE;

				oID = (ch == '*') ? Operation_IDs.OI_MUL : Operation_IDs.OI_DIV;

				OutputID(context, oID, ch.ToString(), context.Position);

				int nPos = context.Position;

				context.Position++;
				node2 = DoSgOP(context);

				node = NewTreeNode(context, node1, node2, oID, nPos);
				node1 = node;

				ch = context.CurrentChar;
			}

			return node1;
		}

		/// <summary>
		/// �����߼���"!"�����
		/// </summary>
		/// <returns></returns>
		private ExpTreeNode DoSgOP(ParsingContext context)
		{
			ExpTreeNode node = null;
			ExpTreeNode node2 = null;

			SkipSpaces(context);

			char ch = context.CurrentChar;

			if (ch == '!')
			{
				OutputID(context, Operation_IDs.OI_NOT, "!", context.Position);

				int nPos = context.Position;

				context.Position++;

				node2 = DoSgOP(context);
				node = NewTreeNode(context, null, node2, Operation_IDs.OI_NOT, nPos);
			}
			else
				node = DoFactor(context);

			return node;
		}

		/// <summary>
		/// ��������ϵ�������������ŵ�
		/// </summary>
		/// <returns></returns>
		private ExpTreeNode DoFactor(ParsingContext context)
		{
			ExpTreeNode node = null;
			ExpTreeNode left = null;
			ExpTreeNode node2 = null;

			SkipSpaces(context);

			char ch = context.CurrentChar;

			int nPos = context.Position;

			if (ch == '-')	//��������
			{
				OutputID(context, Operation_IDs.OI_NEG, "-", context.Position);

				context.Position++;

				node2 = DoExpression(context);

				left = NewTreeNode(context);
				left.OperationID = Operation_IDs.OI_NEG;
				left.Value = (double)-1;
				left.Position = nPos;

				node = NewTreeNode(context, left, node2, Operation_IDs.OI_MUL, nPos);
			}
			else
				if (ch == '(')
				{
					OutputID(context, Operation_IDs.OI_LBRACKET, "(", context.Position);
					context.Position++;
					node = DoExpression(context);

					SkipSpaces(context);

					if (context.CurrentChar != ')')
						throw ParsingException.NewParsingException(ParseError.peCharExpected, context.Position, ")");
					else
						OutputID(context, Operation_IDs.OI_RBRACKET, ")", context.Position);

					context.Position++;
				}
				else
					node = DoIdentifier(context);

			SkipSpaces(context);

			return node;
		}

		/// <summary>
		/// �����������֡���ʶ�����Զ��庯�����ַ�����
		/// </summary>
		/// <returns></returns>
		private ExpTreeNode DoIdentifier(ParsingContext context)
		{
			ExpTreeNode result = null;

			SkipSpaces(context);

			char ch = context.CurrentChar;

			if (ch != '\0')
			{
				if (ch == '#')	//string
					result = DoDatetime(context);
				else
					if (ch == '"')	//string
						result = DoString(context);
					else
						if (Char.IsDigit(ch) || ch == '.')
							result = DoNumber(context);
						else
							if (Char.IsLetter(ch) || ch == '_')
								result = DoFunctionID(context);
							else
								throw ParsingException.NewParsingException(ParseError.peInvalidOperator, context.Position, ch.ToString());

				SkipSpaces(context);
			}

			return result;
		}

		private static ExpTreeNode DoDatetime(ParsingContext context)
		{
			int nPos = context.Position;
			char ch = context.ExpressionChars[++context.Position];

			StringBuilder strB = new StringBuilder(256);

			strB.Append("#");

			while (ch != '\0')
			{
				strB.Append(ch);

				if (ch == '#')
				{
					context.Position++;
					break;
				}

				ch = context.ExpressionChars[++context.Position];
			}

			if (ch == '\0')
				throw ParsingException.NewParsingException(ParseError.peCharExpected, context.Position, "#");

			ExpTreeNode node = NewTreeNode(context);

			node.Position = nPos;
			node.OperationID = Operation_IDs.OI_DATETIME;

			try
			{
				string strID = strB.ToString();
				node.Value = DateTime.Parse(strID);

				OutputID(context, Operation_IDs.OI_DATETIME, strID, nPos);

				return node;
			}
			catch (System.FormatException)
			{
				throw ParsingException.NewParsingException(ParseError.peFormatError, nPos);
			}
		}

		private static ExpTreeNode DoString(ParsingContext context)
		{
			int nPos = context.Position;
			char ch = context.ExpressionChars[++context.Position];

			StringBuilder strB = new StringBuilder(256);
			StringBuilder strIDB = new StringBuilder(256);

			strIDB.Append('"');

			while (ch != '\0')
			{
				if (ch != '"')
				{
					strB.Append(ch);
					strIDB.Append(ch);
					context.Position++;
				}
				else
					if (context.ExpressionChars[context.Position + 1] == '"')
					{
						strB.Append('"');
						strIDB.Append("\"\"");
						context.Position += 2;
					}
					else
					{
						strIDB.Append('"');
						context.Position++;
						break;
					}

				ch = context.CurrentChar;
			}

			if (ch == '\0')
				throw ParsingException.NewParsingException(ParseError.peCharExpected, context.Position, "\"");

			string strID = strIDB.ToString();

			OutputID(context, Operation_IDs.OI_STRING, strID, nPos);
			ExpTreeNode node = NewTreeNode(context);

			node.Position = nPos;
			node.OperationID = Operation_IDs.OI_STRING;
			node.Value = strB.ToString();

			return node;
		}

		private static ExpTreeNode DoNumber(ParsingContext context)
		{
			int nPos = context.Position;
			char ch = context.CurrentChar;

			while (Char.IsDigit(ch) || (ch == '.'))
				ch = context.ExpressionChars[++context.Position];

			ExpTreeNode node = NewTreeNode(context);

			node.Position = nPos;
			node.OperationID = Operation_IDs.OI_NUMBER;

			string ns = new String(context.ExpressionChars, nPos, context.Position - nPos);
			node.Value = double.Parse(ns);

			OutputID(context, Operation_IDs.OI_NUMBER, ns, nPos);

			return node;
		}

		private ExpTreeNode DoFunctionID(ParsingContext context)
		{
			int nPos = context.Position;
			char ch = context.CurrentChar;

			while (char.IsLetterOrDigit(ch) || ch == '_' || ch == '.')
				ch = context.ExpressionChars[++context.Position];

			string strID = new string(context.ExpressionChars, nPos, context.Position - nPos);

			return DoFunction(context, strID);
		}

		private ExpTreeNode DoFunction(ParsingContext context, string strId)
		{
			Operation_IDs oID = Operation_IDs.OI_USERDEFINE;

			ExpTreeNode node = null;

			//string strLower = strID.ToLower();

			//if (strLower == "true" || strLower == "false")
			if (string.Compare(strId, "true", true) == 0 || string.Compare(strId, "false", true) == 0)
			{
				node = NewTreeNode(context);
				node.Position = context.Position - strId.Length;
				node.OperationID = Operation_IDs.OI_BOOLEAN;
				node.Value = bool.Parse(strId.ToLower());

				OutputID(context, Operation_IDs.OI_BOOLEAN, strId, node.Position);
			}
			else
				node = GetFunctionNode(context, oID, strId);

			return node;
		}

		private ExpTreeNode GetFunctionNode(ParsingContext context, Operation_IDs funcID, string strID)
		{
			ExpTreeNode node = null;
			ExpTreeNode nodeTemp = null;
			List<ExpTreeNode> paramBase = new List<ExpTreeNode>(4);

			int nStartFunction = context.Position - strID.Length;

			OutputID(context, Operation_IDs.OI_USERDEFINE, strID, nStartFunction);

			if (context.CurrentChar == '(')	//�в���
			{
				OutputIDToSubLevel(context);
				OutputID(context, Operation_IDs.OI_LBRACKET, "(", context.Position);

				do
				{
					context.Position++;
					SkipSpaces(context);

					nodeTemp = DoExpression(context);

					if (nodeTemp != null)
					{
						paramBase.Add(nodeTemp);

						SkipSpaces(context);
					}
					else
						break;

					if (context.CurrentChar == ',')
						OutputID(context, Operation_IDs.OI_COMMA, ",", context.Position);
				}
				while (context.CurrentChar == ',');

				if (context.CurrentChar == ')')
				{
					OutputID(context, Operation_IDs.OI_RBRACKET, ")", context.Position);
					OutputIDToParentLevel(context);

					context.Position++;
					node = NewTreeNode(context);
					node.Position = nStartFunction;
					node.Params = paramBase;
					node.OperationID = funcID;

					if (funcID == Operation_IDs.OI_USERDEFINE)
						node.FunctionName = strID;
				}
				else
					throw ParsingException.NewParsingException(ParseError.peCharExpected, context.Position, ")");

				SkipSpaces(context);
			}
			else	//û�в���
			{
				node = NewTreeNode(context);
				node.Position = nStartFunction;
				node.Params = paramBase;
				node.OperationID = funcID;

				if (funcID == Operation_IDs.OI_USERDEFINE)
					node.FunctionName = strID;
			}

			return node;
		}

		private static void OutputID(ParsingContext context, Operation_IDs oID, string strID, int nPos)
		{
			if (context.OutputIdentifiers)
			{
				ParseIdentifier pi = new ParseIdentifier(oID, strID, nPos, context.CurrentIdentifier);

				if (context.CurrentIdentifier == null)
				{
					if (context.ParentIdentifier == null)
						context.Identifiers = pi;
					else
						context.ParentIdentifier.SubIdentifier = pi;
				}
				else
					context.CurrentIdentifier.NextIdentifier = pi;

				pi.ParentIdentifier = context.ParentIdentifier;
				context.CurrentIdentifier = pi;
			}
		}

		private static void OutputIDToSubLevel(ParsingContext context)
		{
			context.ParentIdentifier = context.CurrentIdentifier;
			context.CurrentIdentifier = null;
		}

		private static void OutputIDToParentLevel(ParsingContext context)
		{
			if (context.ParentIdentifier != null)
			{
				context.CurrentIdentifier = context.ParentIdentifier;
				context.ParentIdentifier = context.ParentIdentifier.ParentIdentifier;
			}
		}

		/// <summary>
		/// ����һ���µĶ������ڵ�
		/// </summary>
		private static ExpTreeNode NewTreeNode(ParsingContext context)
		{
			ExpTreeNode node = new ExpTreeNode();

			node.Position = context.Position;

			return node;
		}

		/// <summary>
		/// ����һ���µĶ������ڵ�
		/// </summary>
		/// <param name="context">����������</param>
		/// <param name="left">������</param>
		/// <param name="right">������</param>
		/// <param name="oID">��������</param>
		/// <returns></returns>
		private static ExpTreeNode NewTreeNode(ParsingContext context, ExpTreeNode left, ExpTreeNode right, Operation_IDs oID)
		{
			ExpTreeNode node = NewTreeNode(context);

			node.Left = left;
			node.Right = right;
			node.OperationID = oID;

			return node;
		}

		private static ExpTreeNode NewTreeNode(ParsingContext context, ExpTreeNode left, ExpTreeNode right, Operation_IDs oID, int nPosition)
		{
			ExpTreeNode node = NewTreeNode(context, left, right, oID);

			node.Position = nPosition;

			return node;
		}

		private static void SkipSpaces(ParsingContext context)
		{
			while (context.CurrentChar <= ' ' && context.CurrentChar != '\0')
				context.Position++;
		}
		#endregion
		#endregion

		#region public define

		#region public function define

		/// <summary>
		/// ��������ʽ��
		/// </summary>
		/// <param name="expression">����ʽ</param>
		/// <returns>�������</returns>
		/// <remarks>
		/// �Դ���ı���ʽ���з���
		/// <code source="..\Framework\TestProjects\DeluxeWorks.Library.Test\Expression\ExpressionParserTest.cs" region="parse" lang="cs" title="���÷�������ʽ�ĺ���" />
		/// </remarks>
		public static ParseResult Parse(string expression)
		{
			ParseResult result = null;

			if (string.IsNullOrEmpty(expression) == false)
			{
				ParsingContext context = new ParsingContext(expression);

				context.OutputIdentifiers = true;
				ExpTreeNode tree = ExpressionParser.instance.DoExpression(context);

				if (context.CurrentChar != '\0')
					throw ParsingException.NewParsingException(ParseError.peInvalidOperator, context.Position, context.CurrentChar.ToString());

				result = new ParseResult(tree, context.Identifiers);
			}
			else
				result = new ParseResult(null, null);

			return result;
		}

		/// <summary>
		/// �������ʽ��ֱ�ӻ�ý��
		/// </summary>
		/// <param name="expression">����ʽ</param>
		/// <returns>������</returns>
		/// <remarks>
		/// ֱ�Ӽ��������ʽ�Ľ��
		/// <code source="..\Framework\TestProjects\DeluxeWorks.Library.Test\Expression\ExpressionParserTest.cs" region="Calculate" lang="cs" title="�������ʽ" />
		/// </remarks>
		public static object Calculate(string expression)
		{
			return Calculate(expression, null, null);
		}

		/// <summary>
		/// �������ʽ��ֱ�ӻ�ý��
		/// </summary>
		/// <param name="expression">����ʽ</param>
		/// <param name="calculateUserFunction">�Զ��庯��</param>
		/// <param name="callerContext">�Զ��庯��������</param>
		/// <returns>����ֵ</returns>
		/// <remarks>
		/// �԰����Զ��庯���ı���ʽ��������
		/// <code source="..\Framework\TestProjects\DeluxeWorks.Library.Test\Expression\ExpressionParserTest.cs" region="Calculate" lang="cs" title="�������ʽ" />
		/// </remarks>
		public static object Calculate(string expression, CalculateUserFunction calculateUserFunction, object callerContext)
		{
			return Calculate(expression, calculateUserFunction, callerContext, true);
		}

		/// <summary>
		/// �������ʽ��ֱ�ӻ�ý��
		/// </summary>
		/// <param name="expression">����ʽ</param>
		/// <param name="calculateUserFunction">�Զ��庯��</param>
		/// <param name="callerContext">�Զ��庯��������</param>
		/// <param name="optimize">�Ƿ����bool�����Ż���ȱʡΪtrue</param>
		/// <returns>����ֵ</returns>
		/// <remarks>
		/// �԰����Զ��庯�����Զ��������ĵı���ʽ��������
		/// <code source="..\Framework\TestProjects\DeluxeWorks.Library.Test\Expression\ExpressionParserTest.cs" region="Calculate" lang="cs" title="�������ʽ" />
		/// </remarks>
		public static object Calculate(string expression, CalculateUserFunction calculateUserFunction, object callerContext, bool optimize)
		{
			object result = null;
			ParseResult pr = Parse(expression);

			if (pr != null)
				result = GetTreeValue(pr.Tree, calculateUserFunction, callerContext, optimize);

			return result;
		}

		/// <summary>
		/// �����﷨�������Tree����������
		/// </summary>
		/// <param name="tree">�﷨������</param>
		/// <returns>�������ֵ</returns>
		/// <remarks>
		/// ����������Ķ��������õ�������
		/// <code source="..\Framework\TestProjects\DeluxeWorks.Library.Test\Expression\ExpressionParserTest.cs" region="getreevalue" lang="cs" title="�Խ������ɵĶ��������м���" />
		/// </remarks>
		public static object GetTreeValue(ExpTreeNode tree)
		{
			return GetTreeValue(tree, null, null, true);
		}

		/// <summary>
		/// �����﷨�������Tree����������
		/// </summary>
		/// <param name="tree">�������ɵĶ�����</param>
		/// <param name="calculateUserFunction">�û��Զ��庯����ʵ��</param>
		/// <param name="callerContext">�Զ��庯��������</param>
		/// <returns>������</returns>
		/// <remarks>
		///  �Ժ��Զ��庯���ı���ʽ���н��������ɵĶ����������øú�����������ó����ֵ
		/// <code source="..\Framework\TestProjects\DeluxeWorks.Library.Test\Expression\ExpressionParserTest.cs" region="parse" lang="cs" title="�Խ������ɵĶ��������м���" />
		/// </remarks>
		public static object GetTreeValue(ExpTreeNode tree, CalculateUserFunction calculateUserFunction, object callerContext)
		{
			return GetTreeValue(tree, calculateUserFunction, callerContext, true);
		}

		/// <summary>
		/// �����﷨�������Tree����������
		/// </summary>
		/// <param name="tree"></param>
		/// <param name="calculateUserFunction">�û��Զ��庯����ʵ��</param>
		/// <param name="callerContext"></param>
		/// <param name="optimize">�Ƿ����bool�����Ż���ȱʡΪtrue</param>
		/// <returns></returns>
		/// <remarks>
		/// �Ժ��Զ��庯���ı���ʽ���н��������ɵĶ����������øú�����������ó����ֵ
		/// <code source="..\Framework\TestProjects\DeluxeWorks.Library.Test\Expression\ExpressionParserTest.cs" region="parse" lang="cs" title="�Խ������ɵĶ��������м���" />
		/// </remarks>
		public static object GetTreeValue(ExpTreeNode tree, CalculateUserFunction calculateUserFunction, object callerContext, bool optimize)
		{
			return ExpTreeExecutor.Instance.GetValue(tree, calculateUserFunction, callerContext, optimize);
		}

		#endregion

		#endregion
	}
}
