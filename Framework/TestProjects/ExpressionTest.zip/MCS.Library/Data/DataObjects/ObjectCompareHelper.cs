#region
// -------------------------------------------------
// Assembly	��	HB.DataObjects
// FileName	��	ObjectCompareHelper.cs
// Remark	��	
// -------------------------------------------------
// VERSION  	AUTHOR		DATE			CONTENT
// 1.0		    ����	    2008-03-17		����
// -------------------------------------------------
#endregion

using System;
using System.Text;
using System.Collections.Generic;
using MCS.Library.Core;
using System.Reflection;
using System.Web;
using System.Collections.Specialized;
using System.Collections;

namespace MCS.Library.Data.DataObjects
{
    /// <summary>
    /// ����Ƚϵļ�����
    /// </summary>
	public static class ObjectCompareHelper
	{
		/// <summary>
		/// �Ƚ���������
		/// </summary>
		/// <param name="sourceObject">Դ����</param>
		/// <param name="compareObject">�޸ĺ�Ķ���</param>
		/// <returns>�ȽϵĽ��</returns>
		public static CompareResult CompareObject(object sourceObject, object compareObject)
		{
			CompareResult foResult = new CompareResult();//���صĽ��

			//ExceptionHelper.ReferenceEquals(sourceObject, compareObject);//�ж����������Ƿ�����ͬ��ʵ��
			#region �õ���������comparekey����
			//string[] compareKeyFields = null;
            string[] compareKeyFields = null;
			if (null != sourceObject && null != compareObject)
			{
                compareKeyFields = GetCompareKeyFields(sourceObject);
			}
			#endregion
             
			//�õ�PropertyInfo
			PropertyInfo[] pis = null;
			if (null != sourceObject)
				pis = sourceObject.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.FlattenHierarchy);
			else if (null != compareObject)
				pis = compareObject.GetType().GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.FlattenHierarchy);

			if (pis != null && pis.Length > 0)
			{
				#region ����CompareKey���ж�
                bool sameCompareKey = isSameCompareKey(pis, compareKeyFields, sourceObject, compareObject);
                //bool startCompareKey = false;
                //bool sameCompareKey = false;
                //if (null != compareKeyFields)
                //{
                //    foreach (string key in compareKeyFields)//����key
                //    {
                //        foreach (PropertyInfo pi in pis)//����������Ϣ
                //        {
                //            if (pi.Name == key)//��compareKey
                //            {
                //                object oldValue = ((PropertyInfo)pi).GetValue(sourceObject, null);
                //                object newValue = ((PropertyInfo)pi).GetValue(compareObject, null);
                //                sameCompareKey = object.Equals(oldValue, newValue);//�ж�����CompareKey�Ƿ�һ��

                //                startCompareKey = true;
                //            }
                //        }
                //        if (startCompareKey && !sameCompareKey)//��ʼ���жϣ�������һ��KEY��һ���ˣ��������ʣ���KEY���ͱ��˷�ʱ���ж���
                //            break;
                //    }
                //}
				#endregion

				#region �Ƚ϶���
				//����PropertyInfo
				foreach (PropertyInfo pi in pis)
				{
					//������е�����
					object[] attrs = pi.GetCustomAttributes(typeof(PropertyCompareAttribute), false);
					if (attrs.Length > 0)
					{
						PropertyCompareAttribute attr = (PropertyCompareAttribute)attrs[0];//���������Զ��ڶԱ���Ϣ�ı��
						if (attr.RequireCompare)
						{
							#region �Ƚϼ�ֵ
							//object oldValue = null;//����ԭֵ
                            object oldValue = null != sourceObject ? ((PropertyInfo)pi).GetValue(sourceObject, null) : null;
							//object newValue = null;//������ֵ
                            object newValue = null != compareObject ? ((PropertyInfo)pi).GetValue(compareObject, null) : null;
							//bool blnCompare = false;//�Ƿ�һ��
                            //�Ƚ�ֵ�Ƿ���ͬ
                            bool blnCompare = object.Equals(oldValue, newValue);
                           //blnCompare = object.Equals(oldValue, newValue);

							if (!blnCompare)
							{
								CompareResultItem item;
								if (attr.ListObject)
								{
									item = CreateCompareResultItem(attr, "", "", pi);
									item = CompareCollectionObject(oldValue, newValue, item);
								}
								else
								{
									//����һ��Item
									item = CreateCompareResultItem(attr, oldValue, newValue, pi);

									if (attr.IsSubObject)
									{
										item.IsSubObject = true;
										item.ListCompareResult = CompareObject(oldValue, newValue);
									}
								}

								if (sameCompareKey)//Update
								{
									foResult.Updated.Add(item);
								}
								else if (null == sourceObject && null != compareObject)//û��ԭ����,Add
								{
									foResult.Added.Add(item);
								}
								else if (null == compareObject && null != sourceObject)//û���¶���,Delete
								{
									foResult.Deleted.Add(item);
								}
								else//update
								{
									foResult.Updated.Add(item);
								}
							}
							#endregion
						}
					}
				}
				#endregion
			}
			else
				foResult = null;

			return foResult;
		}

		/// <summary>
		/// �Ƚ��������϶���
		/// </summary>
		/// <param name="sourceObject">Դ����</param>
		/// <param name="compareObject">�޸ĺ�Ķ���</param>
        /// <param name="item">�ȽϵĽ��</param>
		/// <returns>�ȽϵĽ��</returns>
		public static CompareResultItem CompareCollectionObject(object sourceObject, object compareObject, CompareResultItem item)
		{
			item.IsListObject = true;
            if (!(sourceObject is IList) || !(compareObject is IList))
            {
                throw new ArgumentException("��������ΪIList����������");
            }

			IList listA = (IList)sourceObject;
			IList listB = (IList)compareObject;

			if ((listA == null || listA.Count < 1) && (listB != null && listB.Count > 0))//ԭ���������ݣ��޸ĺ�������ݣ���˵��ȫ������
			{
                GenerateCompareResult(item.ListCompareResult.Added, listB);
			}
			else if ((listA != null && listA.Count > 0) && (listB == null || listB.Count < 1))//ԭ���������ݣ��޸ĺ�������ݣ���˵��ȫ��ɾ��
			{
                GenerateCompareResult(item.ListCompareResult.Deleted, listA);
                //for (int i = 0; i < listA.Count; i++)
                //{
                //    CompareResult cr = CompareObject(listA[i], null);
                //    if (null != cr && cr.Deleted.Count > 0)
                //    {
                //        for (int j = 0; j < cr.Deleted.Count; j++)
                //        {
                //            item.ListCompareResult.Deleted.Add(cr.Deleted[j]);
                //        }
                //    }
                //}
			}
			else if ((listA != null && listA.Count > 0) && (listB != null && listB.Count > 0))//����������Ƚ�
			{
				#region �õ���������comparekey����
                //string[] compareKeyFields = null;
                //if (null != sourceObject && null != compareObject)
                //{
                //    ObjectCompareAttribute keyAttr =
                //        (ObjectCompareAttribute)ObjectCompareAttribute.GetCustomAttribute(sourceObject.GetType(), typeof(ObjectCompareAttribute));
                //    if (keyAttr != null && keyAttr.KeyField != string.Empty)
                //    {
                //        compareKeyFields = keyAttr.KeyField.Split(',');
                //    }
                //}
                string[] compareKeyFields = null;
                if (null != sourceObject && null != compareObject)
                {
                    compareKeyFields = GetCompareKeyFields(sourceObject);
                }
				#endregion
                ExceptionHelper.TrueThrow(compareKeyFields == null, "�Ҳ���CompareKey�Ķ���");
				//bool startCompareKey = false;
				bool sameCompareKey = false;
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
				for (int i = 0; i < listA.Count; i++)
				{
					for (int j = 0; j < listB.Count; j++)//����B�����Ƿ�����������޸ĺ����Ϣ,���û�У�����ɾ����
					{
						//startCompareKey = false;
						sameCompareKey = false;

						#region ���ӵ��жϰ�����������
						//�õ�PropertyInfo
						PropertyInfo[] pis = listA[0].GetType().GetProperties(
							BindingFlags.Instance | BindingFlags.Public | BindingFlags.FlattenHierarchy);

                        if (pis != null && pis.Length > 0)
                        {
                            //#region ����CompareKey���ж�
                            //if (null != compareKeyFields)
                            //{
                            //    foreach (string key in compareKeyFields)//����key
                            //    {
                            //        foreach (PropertyInfo pi in pis)//����������Ϣ
                            //        {
                            //            if (pi.Name == key)//��compareKey
                            //            {
                            //                object oldValue = ((PropertyInfo)pi).GetValue(listA[i], null);
                            //                object newValue = ((PropertyInfo)pi).GetValue(listB[j], null);
                            //                sameCompareKey = object.Equals(oldValue, newValue);//�ж�����CompareKey�Ƿ�һ��

                            //                startCompareKey = true;
                            //            }
                            //        }
                            //        if (startCompareKey && !sameCompareKey)//��ʼ���жϣ�������һ��KEY��һ���ˣ��������ʣ���KEY���ͱ��˷�ʱ���ж���
                            //            break;
                            //    }
                            //}

                           
                            ////#endregion
                             sameCompareKey = isSameCompareKey(pis, compareKeyFields, listA[i], listB[j]);
							if (sameCompareKey)//����ҵ���ͬ�Ķ���˵�����޸��˵�
							{
								CompareResult cr = CompareObject(listA[i], listB[j]);
								item.ListCompareResult.Added = cr.Added;
								item.ListCompareResult.Updated = cr.Updated;
								item.ListCompareResult.Deleted = cr.Deleted;
							}
						}
						#endregion
					}

					if (!sameCompareKey)//û����ͬ�Ķ���˵����ɾ���˵�
					{
						CompareResult cr = CompareObject(listA[i], null);
						if (null != cr && cr.Deleted.Count > 0)
						{
							for (int k = 0; k < cr.Deleted.Count; k++)
							{
								item.ListCompareResult.Deleted.Add(cr.Deleted[k]);
							}
						}
					}
				}

				for (int i = 0; i < listB.Count; i++)
				{
					for (int j = 0; j < listA.Count; j++)//����B�����Ƿ�����������޸ĺ����Ϣ,���û�У�����ɾ����
					{
						//startCompareKey = false;
						sameCompareKey = false;

						#region ���ӵ��жϰ�����������
						//�õ�PropertyInfo
						PropertyInfo[] pis = listA[0].GetType().GetProperties(
							BindingFlags.Instance | BindingFlags.Public | BindingFlags.FlattenHierarchy);

						if (pis != null && pis.Length > 0)
						{
							#region ����CompareKey���ж�
                            //if (null != compareKeyFields)
                            //{
                            //    foreach (string key in compareKeyFields)//����key
                            //    {
                            //        foreach (PropertyInfo pi in pis)//����������Ϣ
                            //        {
                            //            if (pi.Name == key)//��compareKey
                            //            {
                            //                object oldValue = ((PropertyInfo)pi).GetValue(listA[j], null);
                            //                object newValue = ((PropertyInfo)pi).GetValue(listB[i], null);
                            //                sameCompareKey = object.Equals(oldValue, newValue);//�ж�����CompareKey�Ƿ�һ��

                            //                startCompareKey = true;
                            //            }
                            //        }
                            //        if (startCompareKey && !sameCompareKey)//��ʼ���жϣ�������һ��KEY��һ���ˣ��������ʣ���KEY���ͱ��˷�ʱ���ж���
                            //            break;
                            //    }
                            //}
							#endregion
                            sameCompareKey = isSameCompareKey(pis, compareKeyFields, listA[j], listB[i]);

						}
						#endregion
					}

					if (!sameCompareKey)//B�е�һ�����ݣ���A��û�У�˵���¼ӵ�
					{

						CompareResult cr = CompareObject(null, listB[i]);
						if (null != cr && cr.Added.Count > 0)
						{
							for (int k = 0; k < cr.Added.Count; k++)
							{
								item.ListCompareResult.Added.Add(cr.Added[k]);
							}
						}
					}
				}
			}

			return item;
		}

        private static void GenerateCompareResult(CompareResultItemCollection item, IList listB)
        {
            for (int i = 0; i < listB.Count; i++)
            {
                CompareResult cr = CompareObject(null, listB[i]);
                if (null != cr && cr.Added.Count > 0)
                {
                    for (int j = 0; j < cr.Added.Count; j++)
                    {
                        item.Add(cr.Added[j]);
                    }
                }
            }
        }

		/// <summary>
		/// ����һ���ȽϽ����Item
		/// </summary>
		/// <param name="attr">һ�����Ե�CompareAttribute </param>
		/// <param name="oldValue">ԭֵ</param>
		/// <param name="newValue">��ֵ</param>
		/// <param name="pi">������Ϣ</param>
		/// <returns>�ȽϽ����Item</returns>
		private static CompareResultItem CreateCompareResultItem(PropertyCompareAttribute attr, object oldValue,
			object newValue, PropertyInfo pi)
		{
			CompareResultItem item = new CompareResultItem();//�ȽϽ��ʵ��

			item.PropertyName = pi.Name;//��������
			item.OldValue = oldValue;//ԭֵ
			item.NewValue = newValue;//��ֵ
			item.ObjectType = pi.PropertyType;//�����Ե�����
			item.SortID = attr.SortID;//����
			item.Description = attr.Description;//˵��

			return item;
		}

		/// <summary>
		/// ���л��ȽϽ��
		/// </summary>
		/// <param name="cr">�ȽϽ������</param>
		/// <returns>���л�����ַ���</returns>
		public static string SerializeCompareResult(CompareResult cr)
		{
			return SerializationHelper.SerializeObjectToString(cr, SerializationFormatterType.Binary);
		}

		/// <summary>
		/// �����л��رȽϽ������
		/// </summary>
		/// <param name="serializedGraph">���л�����ַ���</param>
		/// <returns>�ȽϽ������</returns>
		public static CompareResult DeserializeStringToCompareResult(string serializedGraph)
		{
			return SerializationHelper.DeserializeStringToObject<CompareResult>(serializedGraph, SerializationFormatterType.Binary);
		}

        /// <summary>
        /// �õ������comparekey����
        /// </summary>
        /// <param name="sourceObject"></param>
        /// <returns></returns>
        public static string[] GetCompareKeyFields(object sourceObject)
        {
            string[] compareKeyFields = null;

                ObjectCompareAttribute keyAttr =
                    (ObjectCompareAttribute)ObjectCompareAttribute.GetCustomAttribute(sourceObject.GetType(), typeof(ObjectCompareAttribute));
                if (keyAttr != null && keyAttr.KeyField != string.Empty)
                {
                    compareKeyFields = keyAttr.KeyField.Split(',');
                }

            return compareKeyFields;
        }

        private static bool isSameCompareKey(PropertyInfo[] props, string[] compareKeyFields, object sourceObject, object compareObject)
        {
            bool startCompareKey = false;
            bool sameCompareKey = false;
            if (null != compareKeyFields)
            {
                foreach (string key in compareKeyFields)//����key
                {
                    foreach (PropertyInfo pi in props)//����������Ϣ
                    {
                        if (pi.Name == key)//��compareKey
                        {
                            object oldValue = ((PropertyInfo)pi).GetValue(sourceObject, null);
                            object newValue = ((PropertyInfo)pi).GetValue(compareObject, null);
                            sameCompareKey = object.Equals(oldValue, newValue);//�ж�����CompareKey�Ƿ�һ��

                            startCompareKey = true;
                        }
                    }
                    if (startCompareKey && !sameCompareKey)//��ʼ���жϣ�������һ��KEY��һ���ˣ��������ʣ���KEY���ͱ��˷�ʱ���ж���
                        break;
                }
            }

            return sameCompareKey;
        }
	}
    
}
