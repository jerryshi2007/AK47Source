﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MCS.Library.Caching
{
	/// <summary>
	/// CacheNotifyKey和依赖项之间的关系
	/// </summary>
	public class CacheNotifyKeyToDependencies : Dictionary<CacheNotifyKey, DependencyBase>
	{
	}
}
