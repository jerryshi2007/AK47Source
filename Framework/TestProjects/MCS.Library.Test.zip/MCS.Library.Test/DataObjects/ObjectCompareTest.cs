﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MCS.Library.Data.DataObjects;

namespace MCS.Library.Test.DataObjects
{
    [TestClass]
    public class ObjectCompareTest
    {
        [TestMethod]
        public void SingleObjectCompareTest()
        {
            Vendor vendor = new Vendor()
            {
                Code = "123",
                Description = "desc vendor 1",
                Name = "name vendor 1",
                VendorID = "vendorID1",
                CreateDate = DateTime.Now
            };

            Vendor newVendor = new Vendor()
            {
                Description = "desc vendor 2",
                Name = "name vendor 2",
                VendorID = "vendorID1",
                CreateDate = DateTime.Now.AddDays(-1)
            };

            CompareResult result = ObjectCompareHelper.CompareObject(vendor, newVendor);

            OutpuCompareResult(result);

            Assert.AreEqual(0, result.Added.Count);
            Assert.AreEqual(0, result.Deleted.Count);

            //CreateDate不参与比较
            Assert.AreEqual(3, result.Updated.Count);
        }

        [TestMethod]
        [TestCategory("ObjectCompare")]
        public void CompareCollectionTest()
        {
            VendorCollection oldVendors = PrepareOldVendorCollection();
            VendorCollection newVendors = PrepareNewVendorCollection();

            CompareResult result = ObjectCompareHelper.CompareCollectionObject(oldVendors, newVendors);

            OutpuCompareResult(result);
        }

        private static VendorCollection PrepareOldVendorCollection()
        {
            VendorCollection vendors = new VendorCollection();

            vendors.Add(new Vendor()
            {
                Code = "1",
                Description = "vendor 1",
                Name = "vendor 1",
                VendorID = "vendorID1"
            });

            vendors.Add(new Vendor()
            {
                Code = "2",
                Description = "vendor 2",
                Name = "vendor 2",
                VendorID = "vendorID2"
            });

            //将被删除的
            vendors.Add(new Vendor()
            {
                Code = "3",
                Description = "vendor 3",
                Name = "vendor 3",
                VendorID = "vendorID3"
            });

            return vendors;
        }

        private static VendorCollection PrepareNewVendorCollection()
        {
            VendorCollection vendors = new VendorCollection();

            //不变的
            vendors.Add(new Vendor()
            {
                Code = "1",
                Description = "vendor 1",
                Name = "vendor 1",
                VendorID = "vendorID1"
            });

            //变化的
            vendors.Add(new Vendor()
            {
                Code = "2",
                Description = "vendor 22",
                Name = "vendor 22",
                VendorID = "vendorID2"
            });

            //增加的
            vendors.Add(new Vendor()
            {
                Code = "4",
                Description = "vendor 4",
                Name = "vendor 4",
                VendorID = "vendorID4"
            });

            return vendors;
        }

        private static void OutpuCompareResult(CompareResult result)
        {
            Console.WriteLine("Added:");
            OutpuCompareResultItems(result.Added);

            Console.WriteLine("Updated:");
            OutpuCompareResultItems(result.Updated);

            Console.WriteLine("Deleted:");
            OutpuCompareResultItems(result.Deleted);
        }

        private static void OutpuCompareResultItems(CompareResultItemCollection resultItems)
        {
            resultItems.ForEach(item =>
                Console.WriteLine("Property Name: {0}, Old Value: \"{1}\", New Value: \"{2}\"",
                        item.PropertyName, item.OldValue, item.NewValue)
                );
        }
    }
}
